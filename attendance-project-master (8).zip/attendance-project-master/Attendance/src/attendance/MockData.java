/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package attendance;

import Classes.Student;

/**
 *
 * @author mr.Andersen
 */
public class MockData 
{
    void add(Model stud) 
    {
        Student stud1 = new Student();
        stud1.setFamilyName("Trump");
        stud1.setName("Donald");
        stud1.setStudPic("/Image/poop.png");
        stud.add(stud1);
        
        Student stud2 = new Student();
        stud2.setFamilyName("Nikolov");
        stud2.setName("Marin");
        stud2.setStudPic("/Image/sadface.png");
        stud.add(stud2);

        Student stud3 = new Student();
        stud3.setFamilyName("Enevoldsen");
        stud3.setName("Anni");
        stud3.setStudPic("/Image/girl.png");
        stud.add(stud3);
        
        Student stud4 = new Student();
        stud4.setFamilyName("Rask");
        stud4.setName("Kasper");
        stud4.setStudPic("/Image/polser.png");
        stud.add(stud4);
        
        Student stud5 = new Student();
        stud5.setFamilyName("Søresen");
        stud5.setName("Jacob");
        stud5.setStudPic("/Image/devil.png");
        stud.add(stud5);
        
        Student stud6 = new Student();
        stud6.setFamilyName("Andersen");
        stud6.setName("Kristofer");
        stud6.setStudPic("/Image/cool.png");
        stud.add(stud6);
        
        Student stud7 = new Student();
        stud7.setFamilyName("Moniz");
        stud7.setName("Fabio");
        stud7.setStudPic("/Image/happy.png");
        stud.add(stud7);
        
        Student stud8 = new Student();
        stud8.setFamilyName("Sim");
        stud8.setName("Skomandas");
        stud8.setStudPic("/Image/tired.png");
        stud.add(stud8);
        
        Student stud9 = new Student();
        stud9.setFamilyName("Armando");
        stud9.setName("Gionathan");
        stud9.setStudPic("/Image/abu.png");
        stud.add(stud9);
        
        Student stud10 = new Student();
        stud10.setFamilyName("Hansen");
        stud10.setName("Jeppe");
        stud10.setStudPic("/Image/surprised.png");
        stud.add(stud10);
    }
    
}
